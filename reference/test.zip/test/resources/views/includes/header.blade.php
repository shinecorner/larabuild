<div class="navbar">

    <div class="navbar-inner">

        <ul class="nav">
            <li class="nav-item">
                <a class="nav-link" href="/customer/list">Customer</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/category/list">Category</a>
            </li>
{{--            <li><a href="/">Category</a></li>--}}

{{--            <li><a href="/contact">Custome</a></li>--}}

        </ul>

    </div>

</div>
